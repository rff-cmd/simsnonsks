<html>
<head>
</head>
<body background="../../images/Page-BgTexture.jpg" >
<font face="Verdana, Arial, Helvetica, sans-serif" size="+1">
<h1 align="center">Import Data</h1>

<!--<form method="post" enctype="multipart/form-data" action="proses_coa.php">
Import data CoA: <input name="userfile" type="file">
<input name="upload" type="submit" value="Import">
</form>

<form method="post" enctype="multipart/form-data" action="proses_client.php">
Import data Customer: <input name="userfile" type="file">
<input name="upload" type="submit" value="Import">
</form>-->

<form method="post" enctype="multipart/form-data" action="proses_barang.php">
Import data Barang: <input name="userfile" type="file">
<input name="upload" type="submit" value="Import">
</form>

</font>

</body>
</html>